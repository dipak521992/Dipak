/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
struct node{
    int data;
    struct node *link;
};
struct node *insertatbeg(struct node *head,int data)
{
    struct node *temp =  (struct node *) malloc(sizeof(struct node));
    temp->data=data;
    temp->link=head;
    head=temp;
    return head;
}

struct node *insertatend(struct node *head,int data)
{
    struct node *temp =  (struct node *) malloc(sizeof(struct node));
    struct node *p;
    if(head==NULL)
    {
        printf("first time = %d \n",data);
        temp->data=data;
        temp->link=head;
        head=temp;
        return head;
    }
    p =head;
    while(p->link != NULL)
    {
        p=p->link;
    }
    p->link=temp;
    temp->data=data;
    temp->link=NULL;
    p=temp;
    return head;
}

void display(struct node *head)
{

	printf("\nList element is: ");
	while (head != NULL)
	{
		printf("%d--->", head->data);
		head = head->link;
	}
}
int main()
{
    
    struct node *head = NULL;
    /*head=insertatbeg(head,10);
    head=insertatbeg(head,20);
    head=insertatbeg(head,30);
    head=insertatbeg(head,40);
    head=insertatbeg(head,50);*/
    //display(head);
    head=insertatend(head,10);
    head=insertatend(head,20);
    head=insertatend(head,30);
    head=insertatend(head,40);
    head=insertatend(head,50);
    display(head);
    
    return 0;
}
