#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
int counter = 0;
pthread_mutex_t lock; 
void *threadFunc(void *arg)
{
    pthread_mutex_lock(&lock);
    counter = counter +1;
    printf("\n Job %d has started\n", counter);
    printf("\n Job %d has finished\n", counter); 
    pthread_mutex_unlock(&lock);
}
int main()
{
    pthread_t th_id[5];
    pthread_mutex_init(&lock, NULL);
    int i;
    for(i = 0; i <=1; i++)
        pthread_create(&th_id[i],NULL,threadFunc,NULL);
    for(i = 0; i <=1; i++)    
        pthread_join(th_id[i],NULL);
        

    printf("In side Main function\n");
    pthread_mutex_destroy(&lock); 
    return 0;
}



