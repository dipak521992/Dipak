/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
int global = 10;
void *threadFunc1(char name[10])
{
    //sleep(1);
    global++;
    printf("In side threadFunc1 name = %s \n",name);
    printf("global = %d \n",global);
    pthread_exit(NULL);
    //return 100; // Not a good practice to return anything from thread fucntion

}
void *threadFunc2(void *arg)
{
    long int *tid = (long int *)arg;
    long int *temp;
    global++;
    printf("In side threadFunc2 thread id = %ld\n",*tid);
    printf("In side threadFunc2  pthread_self = %ld\n",pthread_self());
    temp = pthread_self();
    if(pthread_equal(tid, pthread_self()))
        printf("Threads are equal\n"); 
    else
        printf("Threads are not equal\n"); 
    
    printf("global = %d \n",global);

}
int main()
{
    pthread_t th_id1,th_id2;
    char name[10] = "Dipak";
    global++;
    pthread_create(&th_id1,NULL,threadFunc1,name);
    pthread_create(&th_id2,NULL,threadFunc2,(void *)&th_id2);
    pthread_join(th_id1,NULL);
    pthread_join(th_id2,NULL);
    printf("th_id2 = %ld\n",th_id2);
    printf("In side Main pthread_self = %ld\n",pthread_self());
    printf("In side Main function\n");
    //printf("Thread return %d\n",ret); // print 0
    printf("global = %d \n",global);

    return 0;
}

