/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int larr[5]={1,2,3,4,5};
    int rarr[5]={1,2,3,4,5};
    int lshift=4,rshift=1;
    int n=5,i=0;
    int temp =0;
    while(lshift) //left shift
    {
        temp=larr[0];
        for(i=0;i<n-1;i++)
        {
            larr[i]=larr[i+1];
        }
        larr[n-1]=temp;
        lshift--;
    }
    for(i=0;i<n;i++)
        printf("%d ",larr[i]);
    printf("\n");
    
    while(rshift) //right shift
    {
        temp=rarr[n-1];
        for(i=n-1;i>0;i--)
        {
            rarr[i]=rarr[i-1];
        }
        rarr[0]=temp;
        rshift--;
    }
    for(i=0;i<n;i++)
        printf("%d ",rarr[i]);
    return 0;
}
