
/* Program to demonstrate time taken by function fun() */
#include <time.h> 
  
// A function that terminates when enter key is pressed 
void fun() 
{ 
    int i=0;
    char ch[5]="Dipak";
    int a =0;
    //for(i=0;i<10000000;i++);
    printf("%s\n",ch);
} 
  
// The main program calls fun() and measures time taken by fun() 
int main() 
{ 
    clock_t t; 
    t = clock(); 
    fun(); 
    t = clock() - t; 
    double time_taken = ((double)t)/CLOCKS_PER_SEC; // in seconds 
  
    printf("fun() took %f seconds to execute \n", time_taken); 
    return 0; 
} 