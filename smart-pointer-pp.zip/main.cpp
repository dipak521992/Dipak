/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <memory>
using namespace std;
class rectangle{
private:
    int lenght,breadth;
public:
    rectangle(int l, int b)
    {
        lenght = l;
        breadth = b;
    }
    int area()
    {
        return lenght * breadth;
    }
};
int main()
{
    unique_ptr<rectangle> ptr(new rectangle(10,5));
    cout<<ptr->area()<<endl;
    unique_ptr<rectangle> ptr2;
    ptr2=move(ptr);
    cout<<ptr2->area()<<endl;
    cout<<ptr->area()<<endl; // seg fault


    return 0;
}
