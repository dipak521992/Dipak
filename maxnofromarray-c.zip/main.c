/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int arr[3]={2,9,35};
    int tarr[3]={0};
    int i =0, j=0, rem =0, maxno =0,temp =0;
    for(i=0;i<3;i++)
    {
        rem=0;
        temp=arr[i];
        while(arr[i])
        {
           rem=arr[i]%10;
           arr[i]=arr[i]/10;
        }
        tarr[i]=rem;
        arr[i]=temp;
    }
    for(i=0;i<3;i++)
    {
        for(j=i+1;j<3;j++)
        {
            if(tarr[i]>tarr[j])
            {
                printf("%d",arr[i]);
            }
        }
    }
    return 0;
}
