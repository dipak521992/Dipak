/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
static int test()
{
    
        b;
      printf("%d",b);  
    return 0;
}
int main()
{
    test();
    return 0;
}

