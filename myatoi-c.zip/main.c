#include <stdio.h>
int myAtoi(char str[3])
{
    int i,sum= 0,n =3;
    for(i=0;i<n;i++)
    {
        sum = sum * 10;
        sum = sum + (str[i] - '0');
    } 
    return sum;
}
int main()
{
    
    printf("%d",myAtoi("432"));

    return 0;
}
