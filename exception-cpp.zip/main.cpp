/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <string>
using namespace std;
class myexception:public exception
{
  public:
  
};
int division(int a, int b) throw(myexception)
{
    if(b==0)
        throw myexception();
    return a/b;
}
int main()
{
   int x = 10, y =0,z;
   try{
        //division(x,y);
        throw 1;
   }
   catch(myexception e)
   {
       cout <<"inside catch ";
   }
   catch(int e)
   {
       cout << e;
   }
   catch(...)
   {
       cout << "inside elipse";
   }
   
   return 0;
}
