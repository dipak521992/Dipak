/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int arr[] = {10,20,15,19,3,43,90,36,48,0};
    int i = 0,temp=0,lenght = 0;
    lenght = sizeof(arr)/sizeof(arr[0]);
    printf("Before sort \n");
    for( i = 0; i < lenght; i++)
        printf("%d ",arr[i]);
    printf("\n");
    for(i=0; i<lenght -1; i++)
    {
        if(arr[i]> arr[i+1])
        {
            temp = arr[i];
            arr[i] = arr[i+1];
            arr[i+1] = temp;
            i = -1;
        }
    }
    printf("After sort \n");
    for( i =0; i<lenght; i++)
        printf("%d ",arr[i]);
    return 0;
}
