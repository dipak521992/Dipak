/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n = 10; // 1010
    int bit=3;
    /* check bit is on or off
    if(n&(1<<(bit-1)))
        printf("on \n");
        
    else
        printf("off \n");*/
 
    printf("setting bit\n");
    
    n = 10;
    bit=3;
    printf("%d\n",n);
    n = (n |(1<<(bit-1))); /* set the bit if off */
    printf("%d\n",n); // output 14
    
    printf("unset bit\n");

    n = 10;
    bit = 4;
    printf("%d\n",n);
    n = (n &(~ (1<<(bit -1)))); /* unset bit */
    printf("%d\n",n); // output 2

    n = 10;
    bit = 1;
    printf("%d\n",n);
    printf("togling bit\n");
    n =  (n ^(1<<(bit-1)));
    printf("%d\n",n);

    return 0;
}

