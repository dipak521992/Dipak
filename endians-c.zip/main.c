#include <stdio.h> 
int main()  
{ 
   unsigned int i = 423; 
   char *c = (char*)&i; 
   if (*c)     
       printf("Little endian %d",*c); 
   else
       printf("Big endian"); 
   return 0; 
} 