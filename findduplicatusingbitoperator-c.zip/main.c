/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    char str[20]="dipakkumarmishra";
    int bit=0,i=0,x=0;
    for(i=0;str[i]!='\0';i++)
    {
        x = 1;
        x = (x << (str[i]-97));
        if((x&bit) > 0)
            printf("%c is duplicate \n",str[i]);
        else
            bit = x|bit;
    }
    return 0;
}
