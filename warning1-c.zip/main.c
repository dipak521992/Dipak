#include <sys/types.h>
#include <sys/shm.h>
#include <sys/ipc.h>
#include <stdio.h>
int main()
{
 key_t key;
 int shmid;
 char *str;
 char ch[100] = "Testing Shared Memory IPC";
 key = ftok("shmfile",65);
 shmid = shmget(key,1024,0666|IPC_CREAT);
 str= (char*) shmat(shmid,(void*)0,0);
 
 printf ("Dipak");
 return 0;
}

