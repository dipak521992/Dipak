/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>


int singledigit(int num);

int main()
{
    
    printf("%d",singledigit(54219));
    return 0;
}
int singledigit(int num)
{
    char *str;
    int temp = 0;
    int len = 0;
    int i;
    str = itoa(num);
    while(temp >= 10)
    {
        temp=0;
        len=strlen(str);
        for(i=0;i<len-1;i++)
        {
            if(str[i]>str[i+1])
            {
                temp = (temp*10) + (str[i] - str[i-1]) - '0';
            }
            else
            {
                temp = (temp*10) + (str[i-1] - str[i]) - '0';
            }
        }
        str=itoa(temp);
    }
    return temp;
}

