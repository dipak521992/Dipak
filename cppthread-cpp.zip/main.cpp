/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <thread>
using namespace std;
using namespace this_thread;
void create_thread(int num)
{
    int i =0;
    for(i=0;i<num;i++)
        cout<<i<<" ";
    cout<<"Inside create_thread Function \n";
    cout <<get_id();

}
class thread_obj{
    public:
    void operator()(int x)
    {
        cout<<"Inside thread_class Function"<< endl;
    }
};
int main()
{
    //thread tobj1(create_thread,10); //using function pointer
    /*for(int i=0;i<1000;i++)
        cout<<i<<" ";*/
    //*tobj1.join();
    cout <<" inside main thread \n";
    cout <<get_id()<<endl;
    thread tobj2(thread_obj(),1);
    tobj2.join();
    
    auto f = [](int x){
        cout<<"using lamda expression as callable\n";
        cout <<x;
        
    };
    
    
    thread thobj3(f,10);
    thobj3.join();
    return 0;
}


