/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
// C program to set precision in floating point numbers 
// using format specifier 
#include <stdio.h> 
#include <stdlib.h>

int main() 
{ 
	char ch[2]="1"; 
	int a = 5;
    printf("%2.2s\n", ch); 
    printf("%2.2d", a); 
	return 0; 
}
