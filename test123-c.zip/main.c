in main()
{
    
    printf ("%d",validate_master_group());
}
int validate_master_group( void )
{
    int ret_code = FALSE;
    int a = 0;
    if( 1 )
        return 0
    else if( a < 0 )
    {
        o_screen_ez_message ("\nMaster Group Number should be Non-negative!");
        return 1;
    }
    return 0;
}

