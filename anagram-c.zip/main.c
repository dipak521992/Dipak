/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    char str1[]="abcaa";
    char str2[]="aaabc";
    int hash[26]={0};
    int i = 0;
    for(i=0;str1[i]!='\0';i++)
        hash[str1[i]-97]+=1;
    for(i=0;str2[i]!='\0';i++)
    {
        hash[str2[i]-97]-=1;
        if((hash[str2[i]-97]) < 0)
        {
            printf("%s and %s is not an anagram string",str1,str2);
            break;
        }
    }
    if(str2[i]=='\0')
        printf("%s and %s is an anagram string",str1,str2);
    return 0;
}

