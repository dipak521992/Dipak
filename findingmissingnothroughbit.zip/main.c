/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int getMissingNo(int arr[], int n); 
int mymissingno(int a[], int n);

int main()
{
    int arr[] = {5,4,1,2};
    int n = sizeof(arr)/sizeof(arr[0]);
    //printf("%d",getMissingNo(arr,n));
    //printf("missing no is %d",mymissingno(arr,n));
    printf("single %d",singledigit(4756));

    return 0;
}

int getMissingNo(int a[], int n) 
{ 
    int i; 
    int x1 = a[0]; /* For xor of all the elements in array */
    int x2 = 1; /* For xor of all the elements from 1 to n+1 */
  
    for (i = 1; i < n; i++) 
        x1 = x1 ^ a[i]; 
  
    for (i = 2; i <= n + 1; i++) 
        x2 = x2 ^ i; 
  
    return (x1 ^ x2); 
} 
int mymissingno(int a[], int n)
{
    int mis = 0;
    int sum =0;
    int i;
    sum = (((n+1) * (n+2)) /2);
    for(i=0;i<n;i++)
        sum = sum - a[i];
    return sum;
    
}
 
int singledigit(int num)
 {
    int rem =0;
    while(num)
    { 
        rem = rem+ (num % 10);
        num = num/10;
        if(num==0 && rem>=10)
        {
            num = rem;
            rem =0;
        }
    } 
    return rem;
 }
