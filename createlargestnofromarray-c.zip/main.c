/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int arr[4]={54,546,548,60};
    int tarr[3]={0};
    int i =0, j=0, rem =0, maxno =0,temp =0;
    for(i=0;i<4;i++)
    {
        
        for (j=0;j<4-ij++)
        {
            
        }
    }
    return 0;
}
